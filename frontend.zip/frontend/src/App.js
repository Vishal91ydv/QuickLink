import React from 'react';
import Shortener from './components/Shortener';

function App() {
  return (
    <div className="app">
      <header>
        <h1>QuickLink</h1>
        <p>Simple URL shortener</p>
      </header>
      <main>
        <Shortener />
      </main>
      <footer>
        <small>Made by Vishal Boss😎</small>
      </footer>
    </div>
  );
}

export default App;
