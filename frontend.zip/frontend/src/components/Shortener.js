import React, { useState } from 'react';
import { shortenUrl } from '../api';

export default function Shortener() {
  const [longUrl, setLongUrl] = useState('');
  const [shortUrl, setShortUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setShortUrl('');
    setError('');
    if (!longUrl.trim()) {
      setError('Please enter a URL');
      return;
    }
    setLoading(true);
    try {
      const data = await shortenUrl(longUrl.trim());
      setShortUrl(data.shortUrl);
    } catch (err) {
      setError(err.message || 'Error creating short url');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = async () => {
    if (!shortUrl) return;
    try {
      await navigator.clipboard.writeText(shortUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setError('Failed to copy. Select and copy manually.');
    }
  };

  return (
    <div className="shortener">
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Enter a long URL ..."
          value={longUrl}
          onChange={(e) => setLongUrl(e.target.value)}
          aria-label="Long URL"
        />
        <button type="submit" disabled={loading}>
          {loading ? 'Shortening...' : 'Shorten'}
        </button>
      </form>

      {error && <div className="error">{error}</div>}

      {shortUrl && (
        <div className="result">
          <a href={shortUrl} target="_blank" rel="noopener noreferrer">
            {shortUrl}
          </a>
          <button onClick={handleCopy}>{copied ? 'Copied!' : 'Copy'}</button>
        </div>
      )}
    </div>
  );
}
