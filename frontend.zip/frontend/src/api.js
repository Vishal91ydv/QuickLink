import axios from 'axios';

const API_BASE = 'http://localhost:5000';
// const API_BASE = 'https://quicklink-backend-gy3r.onrender.com'

export async function shortenUrl(longUrl) {
  try {
    const res = await axios.post(`${API_BASE}/api/url/shorten`, { longUrl });
    return res.data;
  } catch (error) {
    const message = 'Failed to shorten URL';
    throw new Error(message);
  }
}
